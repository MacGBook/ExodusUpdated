﻿namespace Ink.Runtime
{
    public class Glue : Runtime.Object
    {
        public Glue() { }

        public override string ToString ()
        {
            return "Glue";
        }
    }
}

