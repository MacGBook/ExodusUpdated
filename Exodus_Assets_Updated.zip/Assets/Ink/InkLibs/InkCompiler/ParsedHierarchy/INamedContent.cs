﻿
namespace Ink.Parsed
{
    public interface INamedContent
    {
        string name { get; }
    }
}

